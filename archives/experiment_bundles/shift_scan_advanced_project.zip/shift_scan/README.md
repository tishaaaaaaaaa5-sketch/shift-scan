# Shift-Scan: Power-of-Two State Dynamics and Ternary Projections for Mamba-2

**Research prototype, not a validated performance claim.** This repository studies whether selective state-space language models can reduce projection and recurrent-decay cost by combining (i) grouped ternary projections, (ii) discrete power-of-two leak exponents, and (iii) state-aware distillation.

The training/evaluation path uses a **real pretrained Mamba-2 checkpoint** (`state-spaces/mamba2-130m` by default) and a **real streamed text corpus** (`HuggingFaceFW/fineweb-edu`, `sample-10BT` by default). Random tensors appear only in deterministic unit tests and kernel microbenchmarks; they are not training or language-model evaluation data.

## What is implemented

### Proposed research addition: HARPQ

Horizon-Aware Retention Quantization (HARPQ) selects `k` from a discrete grid by minimizing

`sum_{lag=1..H} w_lag * ((a ** lag) - ((1 - 2**(-k)) ** lag)) ** 2`.

This directly targets multi-step memory retention instead of only one-step leak mismatch. It is a local-stationary objective (the current token's decay is treated as constant over the candidate horizon). The code includes a nearest-leak baseline, configurable horizon/lag weighting, calibration on held-out real FineWeb-Edu documents, and tests that the selected candidate minimizes its own finite-horizon objective. This is a proposed contribution to validate against broader prior work, not a guaranteed novelty claim.

| Component | Status | Important qualification |
|---|---|---|
| Mamba-2 PyTorch reimplementation | Implemented, needs official parity check on target environment | Assumes `ngroups=1`, no MLP branch, supported checkpoint layout |
| Ternary QAT projections | Implemented with STE and per-row/group scales | 2-bit packed storage uses one unused code; scales remain FP16 |
| Activation-aware ternary scales | Implemented as an optional EMA of input-channel second moments | Must be ablated against weight-only scales; calibration is learned online during QAT |
| Power-of-two leak grid | Implemented as `A_hat = 1 - 2**(-k)` | The main training/parallel path computes this with floating-point `exp2`/`log1p`, not integer bit shifts |
| HARPQ: horizon-aware retention quantizer | Implemented as a candidate-grid search minimizing weighted multi-lag retention error | Proposed research hypothesis; local-stationary per-token objective, not a proof of global novelty |
| Group-shared decay exponent | Implemented | `--decay-group-size` must divide number of heads |
| Recurrent-state distillation | Implemented | Final per-layer states; selectable normalized MSE, cosine geometry, or hybrid scale+geometry loss |
| Fixed-point integer-shift reference | Implemented in `fixedpoint_state.py` | CPU/GPU PyTorch correctness fallback; fixed-point injection/readout retain floating-point products |
| Integer-state Triton decode kernel | Experimental int32 kernel in `kernels.py` | True right-shift decay; not GPU-validated in this environment and not used for parallel prefill |
| Ternary Triton GEMV | Experimental implementation | Must run on target GPU and compare against FP16 baseline |
| Fused decode scan kernel | Experimental FP32 kernel | Uses `exp2` and floating-point state injection/output products; not a pure integer shift kernel |
| Long-context loss-by-position | Implemented on held-out FineWeb-Edu shard | Report exact sequence lengths and corpus config |
| Energy estimates | Analytic only | Never report these as measured GPU energy |

## Research contribution hypotheses

1. **Discrete recurrent dynamics:** measure the quality/efficiency trade-off from `A_hat = 1 - 2^-k`, including per-head versus group-shared exponents and the distribution of clipped/quantized exponents.
2. **State-aware ternary QAT:** compare output-logit distillation alone with normalized final-state distillation plus logit distillation.
3. **Accumulated error analysis:** use `theory.py` to study how decay, state and input-injection errors propagate through time.
4. **Activation-aware ternary scaling:** compare weight-only scales with scales weighted by input-channel second moments.
5. **HARPQ (proposed):** choose a power-of-two leak exponent by minimizing weighted retention-curve distortion over a finite horizon, rather than only nearest one-step leak. Compare `--decay-quantizer nearest` and `--decay-quantizer horizon`.
6. **Integer-state feasibility:** use `fixedpoint_state.py` and the experimental Triton decode kernel to quantify fixed-point rounding, overflow and target-device performance.
7. **Systems evaluation:** measure packed ternary GEMV and decode latency on actual hardware, with identical precision, batch size and model settings.

These are hypotheses to test, not novelty guarantees. A broader literature search is required before claiming that any component is the first of its kind.

## Data protocol (not toy data)

Default training source:
- Dataset: `HuggingFaceFW/fineweb-edu`
- Configuration: `sample-10BT`
- Split: streaming `train`
- Tokenizer: `EleutherAI/gpt-neox-20b`
- Teacher: pretrained `state-spaces/mamba2-130m`
- Default token budget: 100M tokens (set by CLI)

A deterministic document-level holdout is used:
- Validation: `document_index % val_modulo == 0`
- Training: all other documents
- Default `val_modulo=100`, so validation documents are filtered out before training shuffle.
- Run configs record dataset, subset, split rule and `synthetic_training_data=false`.

The public lm-evaluation-harness tasks (LAMBADA, HellaSwag, PIQA, ARC, WinoGrande, WikiText) are benchmark data, not generated toy examples. For publishable comparisons, report exact harness version, task versions, limits, few-shot setting and checkpoint revision.

## Install

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Use a CUDA GPU for full training and Triton benchmarks. CPU is sufficient for unit tests and the fixed-point reference test.

## Reproducible run order

### 1. Correctness first

```bash
python tests.py
```

Optional official implementation parity check (requires compatible CUDA, `mamba_ssm`, and checkpoint dependencies):

```bash
python tests.py --official
```

### 2. Confirm actual pretrained checkpoint and tokenizer access

```bash
python - <<'PY'
from ssm_core import load_pretrained, QuantConfig, get_tokenizer
model, cfg = load_pretrained("state-spaces/mamba2-130m", QuantConfig())
tok = get_tokenizer()
print("config:", cfg)
print("tokenizer:", tok.name_or_path, "vocab:", len(tok))
print("parameters:", sum(p.numel() for p in model.parameters()))
PY
```

### 3. Evaluate the pretrained teacher

```bash
python eval_lm.py \
  --pretrained state-spaces/mamba2-130m \
  --out results/teacher.json
```

For a quick software smoke test only, use `--limit 100`. Do not use smoke-test limits as final paper results.

### 4. Train the main Shift-Scan student on real FineWeb-Edu

```bash
python calibrate_decay.py \
  --pretrained state-spaces/mamba2-130m \
  --dataset HuggingFaceFW/fineweb-edu --subset sample-10BT \
  --tokens 200000 --horizon 128 --out results/decay_calibration.json

python train_qat.py \
  --name shift_scan_main \
  --pretrained state-spaces/mamba2-130m \
  --dataset HuggingFaceFW/fineweb-edu \
  --subset sample-10BT \
  --tokens 100e6 \
  --seq-len 2048 \
  --decay shift \
  --decay-quantizer horizon \
  --decay-horizon 128 \
  --decay-lag-weight uniform \
  --decay-group-size 1 \
  --ternary 1 \
  --group-size 128 \
  --state-weight 0.05 \
  --state-loss-type hybrid \
  --activation-aware 1 \
  --dtype bf16
```

For an NVIDIA T4, use `--dtype fp16 --micro-bs 2 --accum 16`. Adjust batch size to available memory. Training stops after the specified token budget; monitor logs and checkpoint files. `last.pt` stores model, optimizer, scaler and RNG state. Resume an interrupted run with the same architecture/data/training arguments plus `--resume runs/shift_scan_main/last.pt`; the deterministic stream is advanced past previously consumed microbatches.

### 5. Evaluate quality and long-context behavior

```bash
python eval_lm.py \
  --ckpt runs/shift_scan_main/last.pt \
  --out results/shift_scan_main.json \
  --ppl-length
```

The long-context loss uses the same deterministic held-out document shard as training validation, not the training shard.

### 6. Benchmark actual inference

```bash
python kernels.py
python bench.py \
  --ckpt runs/shift_scan_main/last.pt \
  --out results/shift_scan_main_bench.json \
  --nvml

# Optional integer-state decode path (requires a shift-decay checkpoint)
python bench.py --ckpt runs/shift_scan_main/last.pt --integer-state \
  --state-frac-bits 20 --out results/shift_scan_integer_state.json
```

The benchmark measures both prefill and decode. Prefill inputs are random token IDs used strictly for compute benchmarking, not quality evaluation. Decode reports repeated-trial median/mean/std; NVML power sampling is optional and noisy at short durations. Compare teacher/student at the same dtype and hardware. The analytic energy fields are not measurements.

## Required ablation matrix

Run each configuration with identical token budget, data split, optimizer, tokenizer and evaluation protocol. Repeat important results with at least three seeds.

```bash
# Full-precision teacher/control student
python train_qat.py --name A_exp_fp --decay exp --ternary 0 --tokens 100e6

# Decay-only contribution
python train_qat.py --name B_pot_fp --decay shift --ternary 0 --tokens 100e6

# Ternary-only contribution
python train_qat.py --name C_exp_ternary --decay exp --ternary 1 --tokens 100e6

# Joint Shift-Scan
python train_qat.py --name D_joint_state --decay shift --ternary 1 --state-weight 0.05 --tokens 100e6

# Horizon-aware retention objective (proposed HARPQ contribution)
python train_qat.py --name E_harpq --decay shift --decay-quantizer horizon --decay-horizon 128 --ternary 1 --tokens 100e6

# Generate the complete matched ablation suite; add --run to launch all jobs
python run_ablation.py --tokens 100e6 --seeds 0,1,2 --out-dir runs/ablation --print

# Group-shared decay exponents (choose divisor of model head count)
python train_qat.py --name E_group2 --decay shift --decay-group-size 2 --ternary 1 --tokens 100e6

# Remove state distillation to isolate its effect
python train_qat.py --name F_no_state_loss --decay shift --ternary 1 --state-weight 0 --tokens 100e6

# Activation-aware ternary scales
python train_qat.py --name I_activation_aware --decay shift --ternary 1 --activation-aware 1 --tokens 100e6

# Preserve sensitive in-projection rows
python train_qat.py --name G_dt_fp --decay shift --ternary 1 --fp-rows dt --tokens 100e6
python train_qat.py --name H_bc_fp --decay shift --ternary 1 --fp-rows bc --tokens 100e6
```

`k_step=0.5` is an optional ablation but is **not** an integer right-shift grid. Keep it out of claims about exact bit-shift arithmetic.

## What must be reported

- Teacher/student perplexity and all benchmark task metrics.
- Exact model checkpoint/revision, tokenizer revision, dataset/config, token count, validation split rule, sequence length, seed and software versions.
- Per-layer/per-head `k` histograms, clipping fractions and decay-grid approximation error.
- For HARPQ, report lag-weight definition, horizon, fraction of exponents changed versus nearest-leak quantization, and retention RMSE/MAE by lag.
- State-distillation loss and long-context loss by position bucket.
- Actual packed model size including scale metadata and FP rows.
- Decode latency at batch 1 and larger batches, prefill throughput at 1K/2K/4K (or chosen lengths), peak memory and repeated-run dispersion.
- If energy is claimed, measured NVML/device telemetry with sampling method and uncertainty; otherwise label it analytic.

## Honest implementation boundaries

- The training/parallel Shift-Scan path is **power-of-two decay**, not a true integer bit-shift recurrence. HARPQ also selects a discrete exponent but its training scan still uses floating-point `exp2`/`log1p`. The optional integer-state decode kernel does perform the decay via an integer right shift, but state injection and readout still use floating-point products.
- Integer-state decode is now integrated through a PyTorch fixed-point fallback and an experimental int32 Triton kernel. It is decode-only; parallel prefill/training still uses the floating-point scan. The Triton implementation has not been compiled or benchmarked on a GPU in this environment.
- Projection input scaling, B*x injection, C/state output, normalization, SiLU, convolution and other operations still contain multiplications.
- GPU Triton kernels use ordinary GPU ALUs; they do not imply a dedicated ternary hardware datapath.
- Do not claim "multiplication-free" or measured energy reduction without implementing and profiling the corresponding integer datapath on target hardware.
- The model port's compatibility with the official Mamba-2 implementation must be checked with `python tests.py --official` on the exact software stack before using it for paper results.
