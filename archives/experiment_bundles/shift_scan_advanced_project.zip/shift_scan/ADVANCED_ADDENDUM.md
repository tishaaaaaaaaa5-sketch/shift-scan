# Advanced addendum

| Addition | File | Status |
|---|---|---|
| Dyadic multi-term PoT decay (105 levels at 2 terms) | retention.py, ssm_core.py (`decay_quantizer="dyadic"`), train_qat.py, run_ablation.py rows M,N | code written; level construction verified torch-free; torch tests NOT run in my sandbox |
| Prior-analysis suite S1-S5 + 4 figures | research_suite.py, results/suite/ | executed (NumPy), results reproducible with seed 0 |
| Notebook sections 3b, 5b | shift_scan_advanced_colab.ipynb | not executed (needs Colab GPU for training cells) |

Run `python tests.py` first on your machine: it includes new `test_dyadic_decay` and a parallel-vs-step check for dyadic.
Results in results/suite are init-prior studies, not trained-checkpoint results.
