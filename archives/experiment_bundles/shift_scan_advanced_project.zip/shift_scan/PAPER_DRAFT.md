# Shift-Scan: Research paper scaffold (no results fabricated)

## Working title

**Shift-Scan: Horizon-Aware Power-of-Two State Dynamics and Ternary Projections for Efficient Selective State-Space Language Models**

## Abstract (hypothesis-stage draft)

Selective state-space language models offer constant-size recurrent inference state, but their projections and recurrent updates still rely on conventional floating-point operations. We study a hardware-aware alternative that combines grouped ternary projections with discrete power-of-two recurrent leak coefficients. We introduce **Horizon-Aware Retention Quantization (HARPQ)**, a proposed coefficient-selection objective that chooses a discrete leak exponent by minimizing weighted retention-curve distortion over a finite horizon rather than only one-step coefficient error. The training framework further uses activation-aware ternary scaling and hybrid recurrent-state distillation to constrain the effect of projection and decay approximation on the model's internal dynamics. We evaluate language-model quality, recurrent-state error, long-context loss, packed model size, and measured inference performance against matched full-precision and single-component ablations. All empirical claims will be filled only after running the released experiments on documented hardware and data.

## Contributions to validate

1. **Discrete recurrent dynamics:** replace selected continuous retention coefficients with a configurable power-of-two leak grid, with per-head and group-shared exponent variants.
2. **HARPQ:** select the exponent by minimizing a weighted finite-horizon retention objective. The implemented objective assumes a locally stationary coefficient over the candidate horizon; this approximation and its limitations are explicit.
3. **SSM-aware ternary projections:** use grouped ternary weights with activation-second-moment-aware scales and preserve configurable sensitive projection rows for ablation.
4. **Hybrid recurrent-state distillation:** match teacher/student final states using normalized MSE, cosine geometry and log-RMS terms in addition to output-logit distillation.
5. **Systems validation:** evaluate packed ternary GEMV, fused floating-point PoT decode, and experimental int32 fixed-point decode kernels, while separating measured latency from analytic energy estimates.

## Main equations

Reference state update:

\[
 h_t = a_t h_{t-1} + u_t, \qquad a_t=\exp(\Delta_t A).
\]

Power-of-two leak grid:

\[
 \widehat a_t=1-2^{-k_t},\qquad k_t\in\mathcal K.
\]

HARPQ objective:

\[
 k_t^*=\arg\min_{k\in\mathcal K}\sum_{r=1}^{H}w_r\left(a_t^r-(1-2^{-k})^r\right)^2.
\]

State error recurrence:

\[
 e_t=a_t e_{t-1}+(a_t-\widehat a_t)\widehat h_{t-1}+(u_t-\widehat u_t).
\]

Ternary projection:

\[
 W_q=\gamma_g Q,\quad Q_{ij}\in\{-1,0,+1\}.
\]

## Required experiments

- FP reference, decay-only, ternary-only, joint nearest-leak, joint HARPQ.
- HARPQ horizon sweep (e.g. 16, 32, 64, 128, 256) and lag-weight sweep (uniform/log/early/late).
- Per-head versus group-shared exponents.
- Weight-only versus activation-aware ternary scales.
- Logit KD versus final-state MSE/cosine/hybrid KD.
- Fixed-point precision/overflow sweep using `fixedpoint_state.py`.
- Packed versus unpacked inference on identical GPU, dtype, batch, context and warmup settings.
- At least three random seeds for final comparisons.

## Claims that are prohibited until demonstrated

- Do not claim HARPQ is the first such method without a broad literature and code search.
- Do not call the complete network multiplication-free: normalization, convolution, SiLU, state injection, output projection and other operations still use floating-point multiplies.
- Do not describe the current floating-point `exp2` path as an integer bit shift.
- Do not report analytic energy as measured energy.
- Do not report toy/unit-test outputs as language-model results.
- Do not report speedup until the actual packed kernel is measured against a matched baseline.

## Results table (fill after experiments)

| Method | Validation PPL | Long-context loss | Zero-shot average | Packed size (MB) | Decode tok/s | Peak memory (MB) | Energy/token (measured?) |
|---|---:|---:|---:|---:|---:|---:|---:|
| FP reference | — | — | — | — | — | — | — |
| PoT nearest | — | — | — | — | — | — | — |
| Ternary only | — | — | — | — | — | — | — |
| Joint nearest | — | — | — | — | — | — | — |
| Joint HARPQ | — | — | — | — | — | — | — |
