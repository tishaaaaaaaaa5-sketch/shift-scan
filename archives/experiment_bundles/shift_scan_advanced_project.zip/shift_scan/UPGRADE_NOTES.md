# Upgrade notes

This archive is the upgraded version of the supplied `shift_scan.zip`.

## Added
- **HARPQ (Horizon-Aware Retention Quantization)**: a new proposed research method that selects power-of-two leak exponents by minimizing weighted retention-curve error over a finite horizon, with nearest-leak baseline and configurable lag weights.
- Real-text decay calibration script (`calibrate_decay.py`) and CSV calibration summarizer (`retention_analysis.py`).
- Reproducible ablation command generator/runner (`run_ablation.py`).
- Separate or tied LM-head handling based on checkpoint keys; HF safetensors, PyTorch single-file, and sharded safetensors loading paths.
- Packed ternary inference now mirrors configured activation fake-quantization when activation bits are enabled.
- Hybrid recurrent-state KD with normalized MSE, cosine geometry and log-RMS matching.
- Integrated decode-only int32 fixed-point state mode with a PyTorch reference fallback and experimental Triton integer right-shift kernel; injection/readout remain FP32.
- Activation-aware ternary group scales using EMA input-channel second moments.
- Group-shared decay exponents (`--decay-group-size`).
- Normalized final recurrent-state distillation (`--state-weight`).
- Deterministic disjoint train/validation document filtering for FineWeb-Edu.
- Held-out long-context loss evaluation on the validation shard.
- Fixed-point integer-state shift reference (`fixedpoint_state.py`) with signed rounding and int32 overflow checks.
- Recurrent error-bound helper (`theory.py`).
- Run manifest and packed-size metadata saved with each training run.
- Training checkpoints now preserve optimizer, AMP scaler and RNG state; `--resume` restores the deterministic data stream position and training state.
- Decode benchmarks now use repeated trials and report median/mean/standard deviation; prefill throughput and memory are also measured at configurable sequence lengths.
- Ablation aggregation (`analyze_runs.py`).
- Expanded Colab notebook configured for real pretrained Mamba-2 and FineWeb-Edu, with a 100M-token default budget.
- Research plan with equations, hypotheses, ablation matrix and publication checklist.

## Corrected claims / implementation boundaries
- The existing floating-point scan uses `exp2`/multiplication for power-of-two decay; it is **not** an integer bit-shift recurrence.
- The floating-point Triton scan remains distinct from the experimental integer-state Triton decode kernel. The latter has not been compiled or benchmarked on GPU here.
- The model is multiplication-reduced in selected operators, not multiplication-free end-to-end.
- Energy estimates are analytic only; measured GPU energy must come from target-device telemetry.
- Benchmarks now put teacher and student non-ternary parameters at FP16 for a fairer decode comparison.
- The long-context validation stream is now disjoint from the QAT training stream by document index.

## Verification performed in this environment
- `python tests.py`: passed all CPU unit tests, including scan equivalence, nearest/HARPQ parallel-decode consistency, ternary packing/STE and FP16 execution, activation-aware scales, group-shared decay, fixed-point reference, integer-state decode fallback, recurrent error bound, HARPQ objective, separate LM head and checkpoint round-trip.
- `py_compile`: passed for all Python modules.
- CLI `--help`: passed for training, evaluation, benchmark and aggregation scripts.
- Not run here: pretrained checkpoint download, FineWeb-Edu streaming, full QAT, official `mamba_ssm` parity, CUDA/Triton correctness/performance, NVML energy. This runtime has no CUDA GPU and cannot validate those claims.
