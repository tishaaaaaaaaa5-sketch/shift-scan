# Shift-Scan research plan

## Central question

Can a selective state-space language model retain useful long-context behavior while reducing the cost of (a) projection operators through ternary weights and (b) recurrent state-decay coefficients through a discrete power-of-two grid?

## Mathematical setup

Reference recurrence:

\[
h_t = A_t h_{t-1} + u_t,\qquad A_t=\exp(\Delta_t A).
\]

Power-of-two leak approximation:

\[
\widehat A_t = 1-2^{-k_t},\qquad
k_t = \operatorname{round}\left[-\log_2(1-A_t)\right].
\]

The retention of an input injected at step \(j\) and observed at step \(t\) is:

\[
R_{j,t}=\prod_{i=j+1}^{t} A_i,\qquad
\widehat R_{j,t}=\prod_{i=j+1}^{t}\widehat A_i.
\]

Measure absolute/relative retention error by lag, not only one-step decay error.

For the approximate state \(\hat h_t\), let \(e_t=h_t-\hat h_t\). Then:

\[
e_t=A_t e_{t-1}+(A_t-\widehat A_t)\hat h_{t-1}+(u_t-\widehat u_t).
\]

A norm bound is:

\[
\|e_t\|\le \|A_t\|\|e_{t-1}\|
+\|A_t-\widehat A_t\|\|\hat h_{t-1}\|
+\|u_t-\widehat u_t\|.
\]

`theory.py` provides a scalar/elementwise recurrence for empirical bound checking. Extend it to the actual per-head state norm and prove the assumptions before presenting a formal theorem.

## Proposed additional contribution: HARPQ

**Horizon-Aware Retention Quantization (HARPQ)** selects the power-of-two exponent by minimizing a weighted finite-horizon retention objective:

\[
 k_t^* = \arg\min_{k\in\mathcal K} \sum_{r=1}^{H} w_r\left(a_t^r-(1-2^{-k})^r\right)^2.
\]

This differs from nearest-leak quantization, which primarily minimizes a one-step leak/exponent discrepancy. The current implementation uses a local-stationary approximation: it holds the current scalar decay fixed over each candidate lag. It is not the exact optimal quantizer for a nonstationary sequence. The calibration script compares both methods on real held-out FineWeb-Edu text. Evaluate multiple horizons and lag weights, report the fraction of changed exponents, per-lag retention error, state error and downstream perplexity. A literature search is required before making a novelty claim.

## Contributions to test

### C1. Discrete recurrent decay
Compare original exponential decay against:
- Per-head integer \(k_t\).
- Group-shared \(k_t\).
- Layer-shared \(k_t\).
- Different \(k\)-grid ranges and clipping limits.
- Integer-only \(k\)-steps versus half-step ablations (the latter are not literal shifts).

Report decay-grid error, retention-vs-lag error, `k` histograms, endpoint saturation, state norm and long-context loss.

### C2. Activation- and state-aware ternary QAT
Compare:
- Weight-only ternary group scales.
- Activation-second-moment-weighted scales.
- Logit KD only.
- Logit KD plus normalized final-state KD (MSE, cosine, and hybrid scale+geometry variants).
- Nearest-leak exponent selection versus HARPQ finite-horizon retention selection.
- Joint activation-aware and state-aware training.

Ablate `--activation-aware` and `--state-weight` independently. The activation EMA is a calibration heuristic; do not describe it as an exact optimum without deriving that claim for the implemented ternary thresholding rule.

### C3. Integer-state feasibility
`fixedpoint_state.py` implements a correctness reference and `kernels.py` includes an experimental int32 Triton decode kernel for:

\[
s_t=s_{t-1}-\operatorname{round}(s_{t-1}/2^{k_t})
+\operatorname{round}(2^F u_t).
\]

Study:
- Fractional precision \(F\).
- Signed rounding bias.
- Saturation/overflow.
- State/output deviation from FP32.
- Long-horizon error accumulation.

The integer-state path is decode-only; parallel prefill and QAT still use the floating-point scan. The Triton kernel must be compiled, checked against the PyTorch reference, overflow-tested, and benchmarked on the target GPU before making any speed or energy claims. State injection and readout still use floating-point products.

### C4. Systems performance
Compare:
- Original FP16 teacher.
- Ternary QAT model with simulated/dequantized PyTorch projections.
- Packed ternary GEMV.
- Power-of-two floating-point scan step.
- Fused decode path.

Report prefill and decode separately. Use matched precision and identical hardware. Run warmups and repeated trials; report median and dispersion. Profile actual memory traffic and kernel launches.

## Minimum experimental matrix

| ID | Decay | Projection | Activation-aware | State KD | Purpose |
|---|---|---|---|---|---|
| A | Exponential | FP | No | No | Reference |
| B | PoT | FP | No | Yes | Decay-only |
| C | Exponential | Ternary | No | Yes | Ternary-only |
| D | PoT | Ternary | No | Yes | Joint |
| E | PoT, group-shared | Ternary | No | Yes | Control overhead |
| F | PoT | Ternary | Yes | Yes | Activation-aware scales |
| G | PoT | Ternary | Yes | No | Isolate state KD |
| H | HARPQ | Ternary | Yes | Yes | Test finite-horizon retention objective |

Use the same pretrained checkpoint, tokenizer, FineWeb-Edu document split, sequence length, token budget, optimizer and seed. Run at least three seeds for final claims.

## Evaluation

1. **Language modeling:** validation perplexity and lm-evaluation-harness tasks.
2. **Long context:** loss by token-position buckets and retrieval-style tasks with controlled placement of relevant facts.
3. **State stability:** per-layer state RMS, max magnitude, cosine similarity to teacher, finite-value checks and state error versus sequence length.
4. **Decay quality:** one-step error, retention-vs-lag error, exponent histogram, clipping fractions.
5. **Compression:** exact exported bytes including ternary packing, scale metadata, FP rows, embeddings and non-quantized parameters.
6. **Systems:** prefill throughput, decode tokens/s, per-token latency, peak allocated memory and measured device energy only if instrumentation is reliable.

## Novelty and publication discipline

The five motivating papers establish strong adjacent baselines, but this plan does not establish global novelty. Before submission:
- Search recent papers, preprints, theses and code for quantized/fixed-point SSM recurrences and discrete/PoT decay.
- Compare with released implementations, not only reported numbers.
- Include a table of exactly which operations remain floating point and which are integer.
- Do not call the model multiplication-free: B*x, C*h, gain, normalization, activation and convolution paths still use multiplications in the current implementation.
- Do not claim a true bit-shift in the floating-point scan kernel.
- Report failed ablations and accuracy/latency trade-offs.
