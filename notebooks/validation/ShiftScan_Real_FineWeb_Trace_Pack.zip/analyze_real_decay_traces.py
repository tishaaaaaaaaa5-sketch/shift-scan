#!/usr/bin/env python3
"""Compare decay quantizers on real ordered Mamba-2/FineWeb-Edu decay traces.

Methods:
  * nearest: independently round log2 leak exponent at each token.
  * HARPQ: existing Shift-Scan finite-horizon stationary per-token objective.
  * seq_cd: sequence-aware coordinate refinement that directly minimizes exact
    nonstationary products over observed token windows. This is an *offline*
    diagnostic: it sees the whole sampled sequence and is not yet a causal
    decoding algorithm.

All methods use the same one-term power-of-two candidate set k=1..K.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np
import torch


def parse_args():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--traces", required=True, help="NPZ from capture_real_decay_traces.py")
    p.add_argument("--meta", default=None, help="Metadata JSON; defaults to <trace stem>.meta.json")
    p.add_argument("--out-dir", default="real_trace_analysis")
    p.add_argument("--k-min", type=int, default=1)
    p.add_argument("--k-max", type=int, default=14)
    p.add_argument("--horizon", type=int, default=64)
    p.add_argument("--analysis-length", type=int, default=256)
    p.add_argument("--analysis-sequences", type=int, default=16)
    p.add_argument("--traces-per-sequence", type=int, default=8)
    p.add_argument("--passes", type=int, default=2)
    p.add_argument("--seed", type=int, default=123)
    return p.parse_args()


def np_explicit_loss(a: np.ndarray, q: np.ndarray, horizon: int) -> dict:
    """Exact finite-window objective for a genuinely time-varying decay sequence."""
    a = np.asarray(a, dtype=np.float64)
    q = np.asarray(q, dtype=np.float64)
    T = len(a)
    H = min(horizon, T)
    loga = np.log(np.clip(a, 1e-15, 1.0))
    logq = np.log(np.clip(q, 1e-15, 1.0))
    pa = np.concatenate([[0.0], np.cumsum(loga)])
    pq = np.concatenate([[0.0], np.cumsum(logq)])
    lag_mse, lag_mae, lag_max = [], [], []
    total_sum = 0.0
    total_count = 0
    for lag in range(1, H + 1):
        ref = np.exp(pa[lag:] - pa[:-lag])
        pred = np.exp(pq[lag:] - pq[:-lag])
        err = pred - ref
        lag_mse.append(float(np.mean(err * err)))
        lag_mae.append(float(np.mean(np.abs(err))))
        lag_max.append(float(np.max(np.abs(err))))
        total_sum += float(np.sum(err * err))
        total_count += err.size
    return {
        "nonstationary_retention_rmse_equal_lag": float(np.sqrt(np.mean(lag_mse))),
        "nonstationary_retention_mae_equal_lag": float(np.mean(lag_mae)),
        "nonstationary_retention_max_abs": float(max(lag_max)),
        "nonstationary_retention_rmse_all_windows": float(np.sqrt(total_sum / max(total_count, 1))),
        "one_step_rmse": float(np.sqrt(np.mean((q - a) ** 2))),
        "per_lag_rmse": lag_mse,
    }


def sequence_coordinate_refine(
    a_ref: np.ndarray,
    start_q: np.ndarray,
    candidates: np.ndarray,
    horizon: int,
    passes: int,
) -> np.ndarray:
    """Gauss-Seidel coordinate minimization of exact nonstationary window loss.

    For each coordinate t, only windows containing t can change. Candidate
    products are computed from left/right prefix-log products, so all k values
    are evaluated against exact observed windows without replacing the observed
    trace by a stationary a**lag approximation.
    """
    a_ref = np.asarray(a_ref, dtype=np.float64)
    q = np.asarray(start_q, dtype=np.float64).copy()
    T = len(a_ref)
    H = min(int(horizon), T)
    cand = np.asarray(candidates, dtype=np.float64)
    log_cand = np.log(cand)
    log_ref = np.log(np.clip(a_ref, 1e-15, 1.0))
    offsets = [(left, right, left + right + 1)
               for left in range(H) for right in range(H - left)]
    left_off = np.asarray([z[0] for z in offsets], dtype=np.int64)
    right_off = np.asarray([z[1] for z in offsets], dtype=np.int64)
    lag_arr = np.asarray([z[2] for z in offsets], dtype=np.int64)
    # Equal weight per lag, then equal weight among windows at that lag.
    window_weight = 1.0 / (T - lag_arr + 1.0)
    pref_ref = np.concatenate([[0.0], np.cumsum(log_ref)])

    for pass_idx in range(max(1, passes)):
        order = range(T) if pass_idx % 2 == 0 else range(T - 1, -1, -1)
        for t in order:
            starts = t - left_off
            ends = t + right_off
            valid = (starts >= 0) & (ends < T)
            if not np.any(valid):
                continue
            s = starts[valid]
            e = ends[valid]
            lags = lag_arr[valid]
            weights = window_weight[valid]
            pref_q = np.concatenate([[0.0], np.cumsum(np.log(np.clip(q, 1e-15, 1.0)))])
            left_log = pref_q[t] - pref_q[s]
            right_log = pref_q[e + 1] - pref_q[t + 1]
            ref_product = np.exp(pref_ref[e + 1] - pref_ref[s])
            candidate_log_products = log_cand[:, None] + left_log[None, :] + right_log[None, :]
            candidate_products = np.exp(np.clip(candidate_log_products, -745.0, 0.0))
            errors = candidate_products - ref_product[None, :]
            costs = np.sum((errors * errors) * weights[None, :], axis=1)
            q[t] = cand[int(np.argmin(costs))]

    return q


def choose_trace_indices(S, L, H, n_seq, traces_per_seq, rng):
    seqs = np.arange(S)
    if n_seq < S:
        seqs = np.sort(rng.choice(seqs, size=n_seq, replace=False))
    selected = []
    for s in seqs:
        total = L * H
        take = min(traces_per_seq, total)
        flat = rng.choice(total, size=take, replace=False)
        for j in flat:
            layer, head = divmod(int(j), H)
            selected.append((int(s), layer, head))
    return selected


def bootstrap_sequence_ci(rows, field, reps=2000, seed=991):
    """Bootstrap independent sequence IDs, not correlated heads/layers as IID."""
    by_seq = {}
    for row in rows:
        by_seq.setdefault(row["sequence"], []).append(float(row[field]))
    seq_means = np.asarray([np.mean(v) for v in by_seq.values()], dtype=np.float64)
    if len(seq_means) < 2:
        m = float(seq_means.mean()) if len(seq_means) else float("nan")
        return {"mean": m, "ci95_low": None, "ci95_high": None, "sequences": len(seq_means)}
    rng = np.random.default_rng(seed)
    samples = rng.choice(seq_means, size=(reps, len(seq_means)), replace=True).mean(axis=1)
    return {
        "mean": float(seq_means.mean()),
        "ci95_low": float(np.quantile(samples, 0.025)),
        "ci95_high": float(np.quantile(samples, 0.975)),
        "sequences": int(len(seq_means)),
    }


def main():
    a = parse_args()
    trace_path = Path(a.traces).resolve()
    meta_path = Path(a.meta).resolve() if a.meta else trace_path.with_name(trace_path.stem + ".meta.json")
    out_dir = Path(a.out_dir).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    with np.load(trace_path, allow_pickle=False) as z:
        decay = z["decay_ref"].astype(np.float32, copy=False)
    meta = json.loads(meta_path.read_text()) if meta_path.exists() else {}
    if decay.ndim != 4:
        raise ValueError(f"Expected [sequence, layer, time, head] trace array; found {decay.shape}")
    S, L, T, H = decay.shape
    if not np.isfinite(decay).all() or np.any(decay <= 0) or np.any(decay >= 1):
        raise ValueError("Trace array contains non-finite values or decay outside (0,1)")
    ntime = min(T, a.analysis_length)
    horizon = min(a.horizon, ntime)
    if horizon < 1:
        raise ValueError("horizon must be positive")
    if not (1 <= a.k_min <= a.k_max):
        raise ValueError("require 1 <= k_min <= k_max")

    # Import the exact HARPQ implementation from the project under investigation.
    project_dir = Path(__file__).resolve().parent / "shift_scan_source"
    import sys
    if project_dir.exists():
        sys.path.insert(0, str(project_dir))
    try:
        from retention import exponent_grid, horizon_aware_exponent
    except Exception as exc:
        raise RuntimeError(
            "Could not import Shift-Scan retention.py. Put this script beside the bundled "
            "shift_scan_source/ directory or run it from the research pack."
        ) from exc

    grid_t = exponent_grid(a.k_min, a.k_max, 1.0, device="cpu", dtype=torch.float32)
    grid_k = grid_t.numpy().astype(np.float64)
    candidates = (1.0 - np.exp2(-grid_k)).astype(np.float64)
    rng = np.random.default_rng(a.seed)
    trace_ids = choose_trace_indices(S, L, H, a.analysis_sequences, a.traces_per_sequence, rng)
    rows = []

    for n, (s, layer, head) in enumerate(trace_ids, start=1):
        ar = decay[s, layer, :ntime, head].astype(np.float64)
        at = torch.from_numpy(ar.astype(np.float32))
        k_h, _, k_near, _ = horizon_aware_exponent(at, grid_t, horizon, "uniform")
        q_near = (1.0 - torch.exp2(-k_near)).numpy().astype(np.float64)
        q_harpq = (1.0 - torch.exp2(-k_h)).numpy().astype(np.float64)

        # Sequence-aware optimizer starts from whichever local baseline has
        # the lower exact nonstationary objective, then refines coordinatewise.
        loss_near = np_explicit_loss(ar, q_near, horizon)["nonstationary_retention_rmse_equal_lag"]
        loss_harpq = np_explicit_loss(ar, q_harpq, horizon)["nonstationary_retention_rmse_equal_lag"]
        start = q_near if loss_near <= loss_harpq else q_harpq
        q_seq = sequence_coordinate_refine(ar, start, candidates, horizon, a.passes)

        metrics = {
            "nearest": np_explicit_loss(ar, q_near, horizon),
            "harpq_local_stationary": np_explicit_loss(ar, q_harpq, horizon),
            "sequence_aware_coordinate": np_explicit_loss(ar, q_seq, horizon),
        }
        row = {
            "sequence": s,
            "layer": layer,
            "head": head,
            "out_of_grid_fraction": float(np.mean((ar < candidates[0]) | (ar > candidates[-1]))),
            "changed_vs_nearest_fraction": float(np.mean(np.abs(q_seq - q_near) > 1e-12)),
        }
        for method, vals in metrics.items():
            row[f"{method}_retention_rmse"] = vals["nonstationary_retention_rmse_equal_lag"]
            row[f"{method}_retention_mae"] = vals["nonstationary_retention_mae_equal_lag"]
            row[f"{method}_one_step_rmse"] = vals["one_step_rmse"]
            row[f"{method}_max_abs"] = vals["nonstationary_retention_max_abs"]
        rows.append(row)
        if n == 1 or n % 8 == 0 or n == len(trace_ids):
            print(f"analyzed traces={n}/{len(trace_ids)}", flush=True)

    fields = list(rows[0].keys())
    csv_path = out_dir / "per_trace_metrics.csv"
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

    summary = {
        "status": "analyzed_real_ordered_decay_traces",
        "trace_source_metadata": meta,
        "trace_file": str(trace_path),
        "trace_shape": list(decay.shape),
        "analysis": {
            "sampled_trace_count": len(trace_ids),
            "sampled_sequence_count": len({r["sequence"] for r in rows}),
            "analysis_length": ntime,
            "horizon": horizon,
            "k_grid": list(range(a.k_min, a.k_max + 1)),
            "sequence_aware_passes": a.passes,
            "sequence_aware_method": "offline Gauss-Seidel coordinate refinement on exact observed nonstationary windows",
            "same_candidate_set_for_all_methods": True,
            "seed": a.seed,
        },
        "aggregate_by_sequence_bootstrap_95ci": {},
        "warnings": [
            "This study measures decay-retention approximation error, not language-model perplexity or task accuracy.",
            "The sequence-aware coordinate method is offline and uses the entire sampled sequence; it is not yet a causal decoding kernel.",
            "HARPQ here is the current per-token stationary finite-horizon objective from retention.py.",
            "Confidence intervals bootstrap sequence IDs; heads/layers from one sequence are not treated as independent documents.",
        ],
        "files": {"per_trace_metrics_csv": str(csv_path)},
    }
    for field in [
        "nearest_retention_rmse", "harpq_local_stationary_retention_rmse",
        "sequence_aware_coordinate_retention_rmse", "nearest_one_step_rmse",
        "harpq_local_stationary_one_step_rmse", "sequence_aware_coordinate_one_step_rmse",
        "out_of_grid_fraction", "changed_vs_nearest_fraction",
    ]:
        summary["aggregate_by_sequence_bootstrap_95ci"][field] = bootstrap_sequence_ci(rows, field)

    # Per-method relative change against nearest on the same sampled traces.
    def relative_reduction(base_field, new_field):
        base = np.asarray([r[base_field] for r in rows], dtype=np.float64)
        new = np.asarray([r[new_field] for r in rows], dtype=np.float64)
        return float(1.0 - new.mean() / max(base.mean(), 1e-15))
    summary["mean_relative_retention_rmse_reduction_vs_nearest"] = {
        "harpq_local_stationary": relative_reduction(
            "nearest_retention_rmse", "harpq_local_stationary_retention_rmse"),
        "sequence_aware_coordinate": relative_reduction(
            "nearest_retention_rmse", "sequence_aware_coordinate_retention_rmse"),
    }

    json_path = out_dir / "summary.json"
    json_path.write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2), flush=True)
    print(f"\nSaved: {json_path}\nSaved: {csv_path}", flush=True)


if __name__ == "__main__":
    main()
