#!/usr/bin/env python3
"""Capture ordered, real Mamba-2 decay traces on FineWeb-Edu.

This script runs the *pretrained, unquantized exponential-decay* Mamba-2 model.
It captures each layer/head's actual a_t = exp(softplus(dt + dt_bias) * A)
for each token position, preserving sequence order. It does not train or alter
model weights, and it does not save text, logits, or activations other than the
decay coefficients.

Run from the Shift-Scan project directory, where ssm_core.py is importable.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import time
from pathlib import Path

import numpy as np
import torch


def parse_args():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--project-dir", default=".", help="Directory containing ssm_core.py")
    p.add_argument("--model", default="state-spaces/mamba2-130m")
    # Pin the published checkpoint revision seen in the HF model repository.
    p.add_argument("--model-revision", default="3a5aea0c25d0fb43cc360e2c2aac82c26e3eed49")
    p.add_argument("--expected-model-sha256", default="f786aff903d8b6f2cef67ff2b1db06a9f44e7780340e6ea6d3dead16b52fc501")
    p.add_argument("--tokenizer", default="EleutherAI/gpt-neox-20b")
    p.add_argument("--dataset", default="HuggingFaceFW/fineweb-edu")
    p.add_argument("--subset", default="sample-10BT")
    p.add_argument("--dataset-revision", default="main")
    p.add_argument("--split", default="train")
    p.add_argument("--val-modulo", type=int, default=25,
                   help="Use document indices divisible by this value; 1 means every document")
    p.add_argument("--seq-len", type=int, default=1024)
    p.add_argument("--max-sequences", type=int, default=64)
    p.add_argument("--chunk", type=int, default=64,
                   help="SSD scan chunk; must divide seq-len")
    p.add_argument("--dtype", choices=["fp16", "bf16"], default="fp16")
    p.add_argument("--device", choices=["auto", "cuda", "cpu"], default="auto")
    p.add_argument("--out", default="real_fineweb_mamba2_decay_traces.npz")
    p.add_argument("--meta-out", default="real_fineweb_mamba2_decay_traces.meta.json")
    p.add_argument("--seed", type=int, default=0)
    return p.parse_args()


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def load_checkpoint_pinned(model_id: str, revision: str, chunk: int):
    """Load the HF checkpoint at a fixed revision into this project's Mamba2LM."""
    from huggingface_hub import hf_hub_download
    from safetensors.torch import load_file as safe_load
    from ssm_core import infer_config, Mamba2LM, QuantConfig

    errors = []
    state = None
    source_file = None
    for filename in ("model.safetensors", "pytorch_model.bin"):
        try:
            path = hf_hub_download(model_id, filename, revision=revision)
            state = safe_load(path) if filename.endswith(".safetensors") else torch.load(
                path, map_location="cpu", weights_only=True
            )
            source_file = filename
            break
        except Exception as exc:
            errors.append(f"{filename}: {type(exc).__name__}: {exc}")

    if state is None:
        try:
            index_path = hf_hub_download(
                model_id, "model.safetensors.index.json", revision=revision
            )
            index = json.loads(Path(index_path).read_text())
            state = {}
            for shard in sorted(set(index["weight_map"].values())):
                shard_path = hf_hub_download(model_id, shard, revision=revision)
                state.update(safe_load(shard_path))
            source_file = "model.safetensors.index.json + shards"
        except Exception as exc:
            errors.append(f"sharded safetensors: {type(exc).__name__}: {exc}")
            raise RuntimeError("Could not fetch the pinned Mamba-2 checkpoint:\n" + "\n".join(errors))

    if "state_dict" in state and isinstance(state["state_dict"], dict):
        state = state["state_dict"]
    if "backbone.embedding.weight" not in state and "model.backbone.embedding.weight" in state:
        state = {k.removeprefix("model."): v for k, v in state.items()}

    state = {k: (v.float() if torch.is_floating_point(v) else v) for k, v in state.items()}
    cfg = infer_config(state, chunk=chunk)
    model = Mamba2LM(cfg, QuantConfig(decay="exp"))
    missing, unexpected = model.load_state_dict(state, strict=False)
    ignorable = ("fp_rows", "act_ema")
    missing = [k for k in missing if not k.endswith(ignorable)]
    if missing or unexpected:
        raise RuntimeError(
            f"Checkpoint mismatch. Missing required keys={missing}; unexpected keys={unexpected}"
        )
    return model, cfg, source_file, Path(path) if source_file in ("model.safetensors", "pytorch_model.bin") else None


@torch.inference_mode()
def run_backbone(model, input_ids, device, amp_dtype):
    """Run backbone only: decay computation is identical; avoids giant LM-head logits."""
    from contextlib import nullcontext
    x = model.backbone.embedding(input_ids)
    amp_context = torch.autocast(device_type="cuda", dtype=amp_dtype) if device == "cuda" else nullcontext()
    with amp_context:
        for block in model.backbone.layers:
            x = block(x)
    return x


def main():
    a = parse_args()
    device = ("cuda" if torch.cuda.is_available() else "cpu") if a.device == "auto" else a.device
    if device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but this runtime has no CUDA GPU")
    if a.seq_len < 2 or a.max_sequences < 1 or a.val_modulo < 1:
        raise ValueError("seq-len >= 2, max-sequences >= 1, and val-modulo >= 1 are required")
    if a.seq_len % a.chunk:
        raise ValueError(f"seq-len ({a.seq_len}) must be divisible by chunk ({a.chunk})")

    project_dir = Path(a.project_dir).resolve()
    if not (project_dir / "ssm_core.py").exists():
        bundled_source = Path(__file__).resolve().parent / "shift_scan_source"
        if (bundled_source / "ssm_core.py").exists():
            project_dir = bundled_source
    if str(project_dir) not in os.sys.path:
        os.sys.path.insert(0, str(project_dir))
    if not (project_dir / "ssm_core.py").exists():
        raise FileNotFoundError(f"Could not find ssm_core.py in {project_dir}")

    from transformers import AutoTokenizer
    from datasets import load_dataset

    torch.manual_seed(a.seed)
    np.random.seed(a.seed)
    torch.backends.cuda.matmul.allow_tf32 = True

    t0 = time.time()
    print(f"Loading tokenizer: {a.tokenizer}", flush=True)
    tokenizer = AutoTokenizer.from_pretrained(a.tokenizer, use_fast=True)
    print(f"Tokenizer length={len(tokenizer)}, eos={tokenizer.eos_token_id}", flush=True)

    print(f"Loading pinned pretrained model: {a.model}@{a.model_revision}", flush=True)
    model, cfg, checkpoint_file, checkpoint_path = load_checkpoint_pinned(a.model, a.model_revision, a.chunk)
    checkpoint_sha256 = sha256(checkpoint_path) if checkpoint_path is not None else None
    if a.expected_model_sha256 and checkpoint_sha256 and checkpoint_sha256.lower() != a.expected_model_sha256.lower():
        raise RuntimeError(
            f"Model checkpoint SHA256 mismatch: expected {a.expected_model_sha256}, got {checkpoint_sha256}"
        )
    if len(tokenizer) > cfg.vocab:
        raise RuntimeError(
            f"Tokenizer has {len(tokenizer)} ids but model embedding has {cfg.vocab}; "
            "token IDs may exceed the embedding table. Verify the tokenizer/checkpoint pairing."
        )
    model = model.to(device).eval()
    model.set_track_decay(True)
    amp_dtype = torch.float16 if a.dtype == "fp16" else torch.bfloat16
    if device == "cuda" and a.dtype == "bf16" and not torch.cuda.is_bf16_supported():
        raise RuntimeError("bf16 requested but this GPU does not support bf16; select --dtype fp16")

    from huggingface_hub import HfApi
    dataset_revision_resolved = HfApi().dataset_info(a.dataset, revision=a.dataset_revision).sha
    print(f"Streaming {a.dataset} / {a.subset} ({a.split}) at revision {dataset_revision_resolved}", flush=True)
    ds = load_dataset(
        a.dataset,
        name=a.subset,
        split=a.split,
        streaming=True,
        revision=dataset_revision_resolved,
    )

    token_buffer: list[int] = []
    doc_buffer: list[int] = []
    traces: list[np.ndarray] = []
    doc_spans: list[tuple[int, int]] = []
    selected_docs = 0
    seen_docs = 0
    tokens_seen = 0
    sequence_index = 0
    last_report = time.time()

    for doc_index, example in enumerate(ds):
        seen_docs += 1
        if doc_index % a.val_modulo != 0:
            continue
        text = example.get("text", "")
        if not isinstance(text, str) or not text.strip():
            continue
        ids = tokenizer(text, add_special_tokens=False)["input_ids"]
        if not ids:
            continue
        selected_docs += 1
        token_buffer.extend(ids)
        token_buffer.append(tokenizer.eos_token_id if tokenizer.eos_token_id is not None else 0)
        doc_buffer.extend([doc_index] * (len(ids) + 1))

        while len(token_buffer) >= a.seq_len and len(traces) < a.max_sequences:
            ids_chunk = token_buffer[:a.seq_len]
            docs_chunk = doc_buffer[:a.seq_len]
            del token_buffer[:a.seq_len]
            del doc_buffer[:a.seq_len]
            input_ids = torch.tensor(ids_chunk, dtype=torch.long, device=device).unsqueeze(0)
            if int(input_ids.max()) >= cfg.vocab:
                raise RuntimeError(
                    f"Input token id {int(input_ids.max())} exceeds model vocab {cfg.vocab}; "
                    "refusing to continue with mismatched tokenizer/model."
                )
            _ = run_backbone(model, input_ids, device, amp_dtype)
            layer_traces = []
            for layer_idx, block in enumerate(model.backbone.layers):
                ref = block.mixer.last_decay_ref
                if ref is None:
                    raise RuntimeError(f"Layer {layer_idx} did not expose last_decay_ref")
                # [batch=1, time, heads] -> [time, heads], float32 for precision.
                arr = ref[0].detach().float().cpu().numpy()
                if arr.shape[0] != a.seq_len or arr.shape[1] != cfg.nheads:
                    raise RuntimeError(f"Unexpected decay trace shape at layer {layer_idx}: {arr.shape}")
                layer_traces.append(arr)
            trace = np.stack(layer_traces, axis=0)  # [layer, time, head]
            if not np.isfinite(trace).all() or np.any(trace <= 0.0) or np.any(trace >= 1.0):
                raise RuntimeError("Captured decay coefficients must be finite and strictly between 0 and 1")
            traces.append(trace.astype(np.float32, copy=False))
            doc_spans.append((int(docs_chunk[0]), int(docs_chunk[-1])))
            sequence_index += 1
            tokens_seen += a.seq_len

            if sequence_index == 1 or sequence_index % 8 == 0:
                print(
                    f"captured sequences={sequence_index}/{a.max_sequences} | tokens={tokens_seen:,} | "
                    f"last input docs={doc_spans[-1]}",
                    flush=True,
                )
            if len(traces) >= a.max_sequences:
                break

        if len(traces) >= a.max_sequences:
            break
        if time.time() - last_report > 60:
            print(
                f"streamed documents={seen_docs:,}, selected={selected_docs:,}, "
                f"sequences={len(traces)}", flush=True
            )
            last_report = time.time()

    if not traces:
        raise RuntimeError("No full sequences captured. Check dataset access, tokenizer, and filtering options.")

    trace_array = np.stack(traces, axis=0).astype(np.float32, copy=False)
    out_path = Path(a.out).resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    meta_path = Path(a.meta_out).resolve()
    meta_path.parent.mkdir(parents=True, exist_ok=True)

    np.savez_compressed(
        out_path,
        decay_ref=trace_array,
        source_document_spans=np.asarray(doc_spans, dtype=np.int64),
    )
    elapsed = time.time() - t0
    meta = {
        "status": "captured_real_model_decay_traces",
        "source": {
            "dataset": a.dataset,
            "subset": a.subset,
            "split": a.split,
            "dataset_revision": dataset_revision_resolved,
            "document_sampling_rule": f"document_index % {a.val_modulo} == 0",
            "selected_documents_seen": selected_docs,
            "source_document_spans_per_sequence": doc_spans,
        },
        "model": {
            "repo": a.model,
            "revision": a.model_revision,
            "checkpoint_file": checkpoint_file,
            "checkpoint_sha256": checkpoint_sha256,
            "tokenizer": a.tokenizer,
            "tokenizer_length": len(tokenizer),
            "eos_token_id": tokenizer.eos_token_id,
            "model_config": {
                "d_model": cfg.d_model,
                "n_layer": cfg.n_layer,
                "d_inner": cfg.d_inner,
                "d_state": cfg.d_state,
                "nheads": cfg.nheads,
                "vocab": cfg.vocab,
                "chunk": cfg.chunk,
            },
            "decay_definition": "a_t = exp(softplus(dt_t + dt_bias) * (-exp(A_log)))",
            "quantization": "none; original exponential decay",
            "capture_path": "model.backbone only; skips LM head, but runs all Mamba-2 mixer layers",
        },
        "capture": {
            "sequences": len(traces),
            "seq_len": a.seq_len,
            "tokens_seen_by_model": tokens_seen,
            "trace_shape": list(trace_array.shape),
            "trace_axes": ["sequence", "layer", "time", "head"],
            "trace_dtype": "float32",
            "device": device,
            "amp_dtype_for_forward": a.dtype if device == "cuda" else "fp32_cpu",
            "seed": a.seed,
            "elapsed_seconds": elapsed,
            "python": platform.python_version(),
            "torch": torch.__version__,
            "cuda": torch.version.cuda,
            "gpu": torch.cuda.get_device_name(0) if device == "cuda" else None,
        },
        "artifact": {
            "trace_file": str(out_path),
            "trace_file_bytes": out_path.stat().st_size,
            "trace_sha256": sha256(out_path),
            "metadata_file": str(meta_path),
        },
        "interpretation": (
            "These are ordered decay coefficients computed by the pretrained Mamba-2 model "
            "on tokenized FineWeb-Edu text. They are not synthetic. The saved file contains "
            "decay values and document-index spans, not the raw text or model logits."
        ),
    }
    meta_path.write_text(json.dumps(meta, indent=2))
    print(json.dumps(meta, indent=2), flush=True)
    print(f"\nSaved traces: {out_path}\nSaved metadata: {meta_path}", flush=True)


if __name__ == "__main__":
    main()
