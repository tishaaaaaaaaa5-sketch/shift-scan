# Shift-Scan: real FineWeb-Edu ordered decay-trace study

This pack replaces the previous synthetic-only numerical example with a **real-data capture and analysis pipeline**. It does not claim that real experimental results already exist: the scripts must be run in a GPU/CPU runtime with access to Hugging Face. No empirical FineWeb-Edu numbers are pre-filled or fabricated.

## What is measured

The unquantized pretrained `state-spaces/mamba2-130m` model is run on token sequences streamed from `HuggingFaceFW/fineweb-edu`, configuration `sample-10BT`. For each sequence, layer, token position, and Mamba head, the capture script records the real continuous decay coefficient computed by the Shift-Scan Mamba-2 implementation:

`a[t, layer, head] = exp(softplus(dt[t, layer, head] + dt_bias[layer, head]) * A[layer, head])`

where `A = -exp(A_log)`. The script runs every Mamba mixer block but skips the final language-model head, since logits are not needed to record decay. It does not change model weights, train, quantize, or save raw text/logits.

The output trace tensor has shape `[sequence, layer, time, head]` and is stored in float32 so ordered temporal products are not damaged by float16 rounding.

## Sources and pinned artifacts

- Pretrained model: [`state-spaces/mamba2-130m`](https://huggingface.co/state-spaces/mamba2-130m), pinned to commit `3a5aea0c25d0fb43cc360e2c2aac82c26e3eed49`. The model repository exposes a 24-layer, 768-wide configuration with vocabulary size 50,277. The checkpoint LFS SHA-256 recorded in its commit is `f786aff903d8b6f2cef67ff2b1db06a9f44e7780340e6ea6d3dead16b52fc501`.
- Tokenizer: `EleutherAI/gpt-neox-20b`, matching the tokenizer helper in the uploaded Shift-Scan project. The capture code checks that observed token IDs fit the model embedding table before running.
- Text corpus: [`HuggingFaceFW/fineweb-edu`](https://huggingface.co/datasets/HuggingFaceFW/fineweb-edu), configuration `sample-10BT`, split `train`, streamed at a resolved dataset revision recorded in metadata. The dataset card describes `sample-10BT` as a randomly sampled subset of FineWeb-Edu.
- Model code: `ssm_core.py` and `retention.py` copied from the user's previously uploaded Shift-Scan project archive. Their exact SHA-256 hashes are saved in `source_manifest.json`.

## Experiments compared

All three methods use the same one-term candidate family `a_hat = 1 - 2^-k`, with `k` in `[1,14]` by default.

1. **Nearest** — independent nearest rounding of `-log2(1-a[t])` at each time step.
2. **HARPQ local stationary** — the current `horizon_aware_exponent` implementation from `retention.py`, choosing each token's exponent by matching the stationary curve `a[t]^lag` over the chosen horizon.
3. **Sequence-aware coordinate refinement (Seq-CD)** — starts from whichever of the first two baselines has lower exact nonstationary retention error on that trace, then performs coordinate updates. Each update chooses the exponent that minimizes the exact product error across every observed window containing that time position. This method uses the full sampled sequence (offline/hindsight); it is a diagnostic upper-bound-style comparison, **not yet a causal decoding algorithm**.

For a decay trace `a_1,...,a_T`, the exact retention for a contiguous window is `product(a_j)` over that window. The primary metric averages squared differences between reference and quantized products for every lag up to `H`, with equal weight per lag and equal weight among windows at that lag. The analysis also reports one-step error, max absolute retention error, out-of-grid fraction, and the fraction of positions changed by Seq-CD.

## Run

### Kaggle / Colab

1. Use a separate notebook/runtime from the still-running 20M-token QAT cell. This capture loads another 130M model and runs real FineWeb-Edu inference; do **not** launch it on the same busy T4 while QAT training is running.
2. Enable Internet access and select a GPU (T4 is sufficient for the default sequence length and batch size 1). A CPU fallback is supported, but it will be slower.
3. Upload/extract this pack, install dependencies, and run:

```bash
python capture_real_decay_traces.py \
  --project-dir shift_scan_source \
  --seq-len 1024 --chunk 64 --max-sequences 64 --val-modulo 25 \
  --dtype fp16 --device auto \
  --out real_fineweb_mamba2_decay_traces.npz \
  --meta-out real_fineweb_mamba2_decay_traces.meta.json
```

4. Analyze the real ordered traces:

```bash
python analyze_real_decay_traces.py \
  --traces real_fineweb_mamba2_decay_traces.npz \
  --meta real_fineweb_mamba2_decay_traces.meta.json \
  --out-dir real_trace_analysis \
  --k-min 1 --k-max 14 --horizon 128 \
  --analysis-length 256 --analysis-sequences 24 \
  --traces-per-sequence 1 --passes 1
```

The first run can be shortened with `--max-sequences 8`; use the full default capture for a stronger initial analysis. Increase `--analysis-sequences` and `--traces-per-sequence` only after checking runtime.

## Outputs

- `real_fineweb_mamba2_decay_traces.npz`: ordered float32 traces and sequence-to-source-document spans, no text.
- `real_fineweb_mamba2_decay_traces.meta.json`: model/dataset revisions, source code dimensions, capture settings, trace hash, and environment details.
- `real_trace_analysis/per_trace_metrics.csv`: per-sequence/layer/head comparisons.
- `real_trace_analysis/summary.json`: aggregated metrics and 95% bootstrap intervals that resample sequence IDs, not correlated heads/layers as if independent.

## Interpretation limits

- This evaluates retention-curve approximation on real model decays; it does **not** measure perplexity, downstream task accuracy, speed, memory, energy, or the quality of a trained Shift-Scan student.
- The sequence-aware coordinate method is offline and uses future positions in the sampled sequence. It cannot be represented as a causal decoding improvement without a separate causal algorithm.
- The 24 sequence-level bootstrap groups in the default analysis are still a pilot sample. Increase the number of independently captured sequences and repeat the trace subset with another seed before claiming a robust population effect.
- The pretrained Mamba-2 model is trained on the Pile; FineWeb-Edu is a separate text source. This study is a model-decay diagnostic, not a test of the pretrained model's FineWeb-Edu language-model quality.
- The model forward is executed by the user's pure-PyTorch `ssm_core.py` reimplementation. The checkpoint loader enforces that required weights load with no missing or unexpected keys, but an independent comparison to the official Transformers implementation remains a separate validation step.

## Reproducibility

Both scripts print their configuration and save machine-readable metadata. Preserve the NPZ, metadata JSON, per-trace CSV, summary JSON, the uploaded source archive, and exact Kaggle/Colab logs together. Do not mix these calibration diagnostics with the 20M-token QAT training/evaluation metrics.
