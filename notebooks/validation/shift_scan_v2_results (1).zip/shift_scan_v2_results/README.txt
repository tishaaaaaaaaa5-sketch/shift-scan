Shift-Scan v2 results folder (rebuilt from your console log)

WHAT THE NOTEBOOK REALLY NEEDS (only these two):
  runs.jsonl        28 records = 15 real v1 runs (from your uploaded file) + 13 v2 runs rebuilt from the log
                    (7 ablations, v2_best x3 seeds, v2_best_nearest, v2_best_dyadic2, v2_best_long 12M tokens).
                    Rebuilt records have "reconstructed_from_console_log": true. They lack WikiText, LAMBADA, long-context
                    numbers, checkpoints and timestamps, because the log never printed them.
  best_config.json  the exact BEST CONFIG printed in the log.

tables_from_log/    optional, for reference only (the notebook does not read them). Values are exactly as printed (rounded as printed).
                    stage1_sensitivity_top10_PARTIAL.csv has only the 10 rows the log printed, not all 48.

NOT in the log, so NOT created (they will appear when the unfinished stages run):
  v2_int8 / v2_int4 / v2_plain_twn runs (int8 was at step 72 of 244 when the log ends), benchmarks (HellaSwag/ARC-e/PIQA),
  embedding-quantization results, statistics table, FINAL_REPORT_V2.md, checkpoints.

HOW TO RESUME (Colab):
  1. Put this whole folder in Google Drive at MyDrive/shift_scan_v2_results/ (the notebook mounts Drive and uses that path).
  2. In cell 1 of the notebook set  DO["sens"] = False  and  DO["ablate"] = False  (the chosen config is loaded from best_config.json).
  3. Run all. Finished runs are skipped; remaining stages (int8, int4, plain twn, benchmarks, embedding quantization, report) will run.
  Optional: to get benchmark numbers for the improved model, delete the v2_best seed-0 line from runs.jsonl so it retrains
  with a checkpoint (about 45 minutes).
